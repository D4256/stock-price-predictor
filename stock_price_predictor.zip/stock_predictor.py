# Stock Price Predictor - Linear Regression
# Install required libraries (if not already installed):
# pip install yfinance pandas numpy matplotlib scikit-learn

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import yfinance as yf
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

# 1. Load Stock Data (e.g., Apple Inc.)
stock_symbol = 'AAPL'
data = yf.download(stock_symbol, start='2018-01-01', end='2023-12-31')

# 2. Preprocessing
data = data[['Close']]
forecast_days = 30
data['Prediction'] = data[['Close']].shift(-forecast_days)

# 3. Features and Labels
X = np.array(data.drop(['Prediction'], axis=1))[:-forecast_days]
y = np.array(data['Prediction'])[:-forecast_days]

# 4. Train/Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 5. Train Model
model = LinearRegression()
model.fit(X_train, y_train)

# 6. Test Prediction
predictions = model.predict(X_test)
mse = mean_squared_error(y_test, predictions)
print(f"Mean Squared Error: {mse:.2f}")

# 7. Predict Next 30 Days
X_future = data.drop(['Prediction'], axis=1)[-forecast_days:]
future_predictions = model.predict(X_future)

# 8. Plotting Results
plt.figure(figsize=(12, 6))
plt.title(f"{stock_symbol} Stock Price Prediction (Next {forecast_days} Days)")
plt.plot(data['Close'], label='Historical Price', linewidth=2)
plt.plot(np.arange(len(data), len(data)+forecast_days), future_predictions, label='Predicted Price', linestyle='--', color='red')
plt.xlabel("Days")
plt.ylabel("Price (USD)")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
