# 📈 Stock Price Predictor

A simple project using **Linear Regression** to predict future stock prices based on historical closing price data.

## 📦 Features
- Real-time historical stock data using `yfinance`
- 30-day future price prediction
- Visual comparison of historical vs predicted prices

## ▶️ How to Run

1. Install requirements:
```bash
pip install -r requirements.txt
```

2. Run the Python file:
```bash
python stock_predictor.py
```

## 🛠 Requirements

- yfinance
- pandas
- numpy
- matplotlib
- scikit-learn
